export class Tickets {
  _id: String;
  reporter: String;
	title: String;
	complexcity: String;
  createdat: Date;
  duedateat: Date;
	assignee: String;
}
