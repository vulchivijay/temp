import { Tickets } from './tickets.model';

describe('Tickets', () => {
  it('should create an instance', () => {
    expect(new Tickets()).toBeTruthy();
  });
});
