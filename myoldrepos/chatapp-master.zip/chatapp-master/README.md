# chatapp

Creating a app just like slack modal.
Using reactjs, react-redux, firebase.

![register screen](https://github.com/vulchivijay/chatapp/blob/master/assets/demo-images/register.jpg)
![login screen](https://github.com/vulchivijay/chatapp/blob/master/assets/demo-images/login.jpg)
![mainpage screen](https://github.com/vulchivijay/chatapp/blob/master/assets/demo-images/mainpage.jpg)
![mainpage1 screen](https://github.com/vulchivijay/chatapp/blob/master/assets/demo-images/mainpage1.jpg)
