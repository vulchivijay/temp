# graphs
A sample dashboard with canvasjs.

Used Nodejs environment. Used Expressjs, Bootstrap frameworks.
Plugins used Canvas.js, jvmap.js for graphs.

To run this application in localmachine, please follow below steps

0. Hope you have node environment in your machine.
1. Clone the repo.
2. Open terminal (Mac) -> Go the root folder i.e graphs.
3. run: npm install
4. DEBUG=graphs:* npm start
5. Click or enter the url in browser http://localhost:3000/

<img src="https://github.com/vijayvulchi/graphs/blob/master/public/images/dark-theme.png" alt="dashboard-dark"/>

<img src="https://github.com/vijayvulchi/graphs/blob/master/public/images/light-theme.png" alt="dashboard-light"/>
