import firebase from "firebase/app";
import 'firebase/auth';
import 'firebase/database';
import 'firebase/storage';

// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyDSMx5uwQyN1lJDYt6kq6jiIk3oTYmjnaI",
  authDomain: "slack-clone-react-9a4b3.firebaseapp.com",
  projectId: "slack-clone-react-9a4b3",
  storageBucket: "slack-clone-react-9a4b3.appspot.com",
  messagingSenderId: "805927163482",
  appId: "1:805927163482:web:864dda1914e30e341fea63"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase;