# slack-clone-react-redux-firebase
Building a full stack app (slack clone using react-redux-firebase)
